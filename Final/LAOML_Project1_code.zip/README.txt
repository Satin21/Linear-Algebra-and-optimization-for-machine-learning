# LAOML

We have added a python script for each exercise separately.
In each script, we defined the necessary functions and added comments,
so they are self-contained.
The function to compress images using SVD is present in the script 1a.py.

Sofia, Sathish, Hans, Omar